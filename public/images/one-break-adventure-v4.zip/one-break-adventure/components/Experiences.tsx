import Image from "next/image";

const WHATSAPP_NUMBER = "5493513124567";

const experiences = [
  {
    id: "cabalgata-corta",
    title: "CABALGATA CORTA",
    duration: "2 horas",
    level: "Todos los niveles",
    description: "Un recorrido perfecto para conectarte con la naturaleza y las sierras cordobesas a caballo.",
    highlight: "Ideal para principiantes",
    image: "/images/chico-montando-1.png",
    imageAlt: "Vista en primera persona de cabalgata en las sierras",
    featured: false,
    msg: "Hola! Quiero consultar sobre la Cabalgata Corta.",
  },
  {
    id: "cabalgata-full-day",
    title: "CABALGATA FULL DAY",
    duration: "8 horas",
    level: "Todos los niveles",
    description: "Día completo a caballo, almuerzo criollo incluido en la montaña. La experiencia más completa.",
    highlight: "⭐ Más popular",
    image: "/images/grupo-1.jpeg",
    imageAlt: "Grupo completo en cabalgata full day",
    featured: true,
    msg: "Hola! Quiero consultar sobre la Cabalgata Full Day.",
  },
  {
    id: "trekking-sierras",
    title: "TREKKING ENTRE SIERRAS",
    duration: "6 horas",
    level: "Nivel medio",
    description: "Caminatas guiadas por los paisajes más increíbles de Córdoba. Naturaleza pura y senderos únicos.",
    highlight: "Paisajes únicos",
    image: "/images/chico-montando-2.png",
    imageAlt: "Jinete en cerro con paisaje serrano amplio",
    featured: false,
    msg: "Hola! Quiero consultar sobre el Trekking entre Sierras.",
  },
];

export default function Experiences() {
  return (
    <section id="experiencias" className="py-24 lg:py-32 bg-[#0f1a0c]" aria-labelledby="experiences-heading">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="reveal flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-forest-500" />
            <span className="section-label">Nuestras Experiencias</span>
            <div className="w-8 h-px bg-forest-500" />
          </div>
          <h2
            id="experiences-heading"
            className="reveal text-6xl sm:text-7xl lg:text-8xl text-white leading-none"
            style={{ fontFamily: "var(--font-display)", letterSpacing: "0.02em" }}
          >
            ELEGÍ TU AVENTURA
          </h2>
          <p className="reveal mt-4 text-white/50 text-lg max-w-xl mx-auto" style={{ fontFamily: "var(--font-body)", fontWeight: 300 }}>
            Experiencias diseñadas para que te desconectés de la rutina y te conectés con la naturaleza.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {experiences.map((exp, i) => (
            <article
              key={exp.id}
              className={`reveal reveal-delay-${i + 1} group relative flex flex-col rounded-sm overflow-hidden 
                border border-forest-800/40 bg-[#111d0d] 
                hover:border-forest-600/60 hover:-translate-y-2
                transition-all duration-500 hover:shadow-[0_20px_60px_rgba(0,0,0,0.5)]
                ${exp.featured ? "ring-1 ring-[#c8a45a]/40" : ""}`}
            >
              {/* Featured badge */}
              {exp.featured && (
                <div
                  className="absolute top-4 right-4 z-10 bg-[#c8a45a] text-black text-xs font-semibold px-3 py-1 rounded-sm tracking-wide"
                  style={{ fontFamily: "var(--font-condensed)", letterSpacing: "0.1em" }}
                >
                  {exp.highlight}
                </div>
              )}

              {/* Real image */}
              <div className="relative w-full h-52 sm:h-56 overflow-hidden">
                <Image
                  src={exp.image}
                  alt={exp.imageAlt}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                  sizes="(max-width: 768px) 100vw, 33vw"
                  loading="lazy"
                />
                {/* Dark overlay on image */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#111d0d] via-transparent to-transparent" />
              </div>

              {/* Content */}
              <div className="flex flex-col flex-1 p-6">
                <h3
                  className="text-2xl text-white leading-tight mb-3"
                  style={{ fontFamily: "var(--font-display)", letterSpacing: "0.03em" }}
                >
                  {exp.title}
                </h3>

                {/* Meta */}
                <div className="flex flex-wrap gap-3 mb-4">
                  <span className="flex items-center gap-1.5 text-white/50 text-sm" style={{ fontFamily: "var(--font-body)" }}>
                    <ClockIcon /> {exp.duration}
                  </span>
                  <span className="flex items-center gap-1.5 text-white/50 text-sm" style={{ fontFamily: "var(--font-body)" }}>
                    <UserIcon /> {exp.level}
                  </span>
                </div>

                <p className="text-white/50 text-sm leading-relaxed mb-5 flex-1" style={{ fontFamily: "var(--font-body)", fontWeight: 300 }}>
                  {exp.description}
                </p>

                {!exp.featured && (
                  <p className="text-forest-400 text-xs mb-4" style={{ fontFamily: "var(--font-condensed)", letterSpacing: "0.08em" }}>
                    {exp.highlight}
                  </p>
                )}

                {/* CTA */}
                <div className="mt-auto pt-5 border-t border-forest-800/30">
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(exp.msg)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full flex items-center justify-center gap-2 text-sm font-semibold px-4 py-3 rounded-sm
                                transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 tracking-widest
                                ${exp.featured
                                  ? "bg-[#c8a45a] hover:bg-[#d4b06a] text-black hover:shadow-[0_0_20px_rgba(200,164,90,0.4)]"
                                  : "bg-forest-600 hover:bg-forest-500 text-white hover:shadow-[0_0_20px_rgba(77,115,64,0.4)]"
                                }`}
                    style={{ fontFamily: "var(--font-condensed)", letterSpacing: "0.12em" }}
                    aria-label={`Consultar sobre ${exp.title}`}
                  >
                    CONSULTAR
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function ClockIcon() {
  return <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>;
}
function UserIcon() {
  return <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>;
}
